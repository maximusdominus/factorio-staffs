require("prototypes.items")
require("prototypes.entities")
require("prototypes.recipes")