-- As usual for configs, playing multiplayer will require all players to have the same config as the server.

 -- 10
 sot.config.max_magnitude = 40

-- 4
sot.config.tick_rate = 30

sot.config.speed_magnitude_max = 15
